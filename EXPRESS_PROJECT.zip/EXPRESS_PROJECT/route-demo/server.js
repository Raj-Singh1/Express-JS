const express = require("express");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const commonRoutes = require("./routes/common-routes");
const productRoutes = require("./routes/product-routes");
// create express app object
var app = express();
var path = require("path")

//middleware


app.use("/about", (req, res, next) => {
    req.author = "Ratna Sagar";
    req.verified = true;
    next();
})


//for css
app.use(express.static(path.resolve(__dirname,"public")));
//cookie middleware
app.use(cookieParser("mysecretkey"));
//session middleware
app.use(session({ name: "session",
                  resave: true, 
                  saveUninitialized: true, 
                  secret: "mysecretsessionkey" 
                }));
//configure routes

 app.use("/",commonRoutes)
module.exports = app;

app.use("/products",productRoutes);

function test(req, res, next) {
    req.mes = "hello all";
    next();
}

