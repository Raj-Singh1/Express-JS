// var {readSync,writeContentSync,writeContent} = require("./file-handler");
// var {writeToFileStream,readFromFileStream} = require("./stream-demo");
// var data = "Hello, how are you man?";
// var filename = "greet2.txt"; 
// var fs = require("fs");
// var path = require("path")
// //writeContent(filename,data);
// // readContent(filename,(back)=>{
// //     console.log(back);
// // });
// // writeContentSync(filename,data);
// // readSync(filename);


// // var filepath = path.resolve(__dirname, "myfile", filename);
// // fs.stat(filepath,(err,stats)=>{
// //     console.log(stats);
// // }
// // );

// // fs.watchFile(filepath,(current,prev)=>{
// //     console.log(prev.size +"----"+current.size)
// // })

// writeToFileStream(filename,data);
// readFromFileStream(filename);
//var {RequestHandler} = require("./request-handler")
var http = require("http");
const app =require("./server");


var server = http.createServer(app);

server.listen(5000,(err)=>{
    if(err)
    {
        console.log("could not start server");
    }
    console.log("server started");
})

