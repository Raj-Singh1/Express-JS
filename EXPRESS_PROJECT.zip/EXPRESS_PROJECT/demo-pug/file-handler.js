var fs = require("fs");
var path = require("path")

exports.writeContent = (filename, content) => {
    var filepath = path.resolve(__dirname, "myfile", filename);
    fs.open(filepath, "w", (err, fd) => {
        if (err) {
            console.log("Failed to open file");
            return;
        }
        fs.write(fd, Buffer.from(content), (err, noOfByte, buff) => {
            if (err) {
                console.log("Failed to write content");
                return;
            }
            
            console.log("success");
            fs.close(fd, (err) => {
                if (err) {
                    console.log("error in closing file")

                }
                console.log("file closed");
            })
        })
    })
}

exports.readContent = (filename,callback) => {
    var filepath = path.resolve(__dirname, "myfile", filename);

    fs.open(filepath, "r", (err, fd) => {
        if (err) {
            console.log("error in opening file", err);
            return;
        }
        var buffer = Buffer.alloc(1024);
        fs.read(fd, buffer, 0, 1024, 0, (err, bytesRead, buff) => {
            if (err) {
                console.log("failed to read");
                return;
            }
            callback(buff.toString().toUpperCase());
            fs.close(fd, (err) => {
                console.log("file closed")
            });
        });
    });
}

exports.writeContentSync=(filename,content)=>{
    var filepath = path.resolve(__dirname,"myfile",filename);
    var fd = fs.openSync(filepath,"w");
    if(!fd){
        console.log("failed to open file");
        return;
    }
    var bytes = fs.writeSync(fd,Buffer.from(content));
    console.log("File written successfully");
    fs.closeSync(fd);

}

exports.readSync = (filename)=>{
    var filepath = path.resolve(__dirname,"myfile",filename);
    var fd = fs.openSync(filepath,"r");
    if(!fd){
        console.log("failed to open file");
        return;
    }
    var buffer = Buffer.alloc(1024);
    var bytes = fs.readSync(fd,buffer,0,1024,0);
    console.log(buffer.toString(),bytes);
    fs.closeSync(fd);
}

