const express = require("express");
var Product = require("../models/product-model");
var router = express.Router();

// var products=[
//     {id:1, name:"Aam", quantity:10, price:100},
//     {id:2, name:"Kheera", quantity:10, price:100},
//     {id:3, name:"Kantap", quantity:10, price:100},
//     {id:4, name:"Orange", quantity:10, price:100},
//     {id:5, name:"Jamun", quantity:10, price:100}
// ];


// router.get("/list", (req, res) => {
//     var model={
//         caption: "Products List",
//         items: products
//     };
//     res.header("Content-Type", "text/html").render("product-list", model);
// });


router.get("/list", (req,res)=>{
    var model={
        caption: "Product List"
    };
    Product.find((err,result)=>{
        if(err){
            model.items = undefined;
        }
        else{
            model.items = result;
        }
        res.header("`Content-Type", "text/html").render("product-list", model);
    });
});

router.get("/add", (req, res) => {
    res.header("Content-Type", "text/html")
        .send("Product added");
});

router.get("/remove", (req, res) => {
    res.header("Content-Type", "text/html")
        .send("Product removed");
});



// router.get("/add", (req, res) => {
//     var model={
        
//     }
//     res.header("Content-Type", "text/html").render("Product Added")
// });

// router.get("/remove", (req, res) => {
//     res.header("Content-Type", "text/html").send("Product Removed")
// });

module.exports = router;