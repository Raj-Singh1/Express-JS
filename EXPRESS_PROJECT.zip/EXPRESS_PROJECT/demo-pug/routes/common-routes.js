const express = require("express");
const User = require("../models/user-model");
var bcrypt = require("bcryptjs");
var router = express.Router();



router.get("/", (req, res) => {
    res.header("Content-Type", "text/html").render("index")
});

router.get("/about", (req, res) => {
    res.header("Content-Type", "text/html").render("About")
});

router.get("/contact", (req, res) => {
    res.header("Content-Type", "text/html").render("Contact")
});

router.get("/register", (req, res) => {
    res.header("Content-Type", "text/html")
        .render("register");
});

//POST/register
router.post("/register",(req,res)=>{
    // var formData=req.body;
    // console.log(formData);
    // res.send(formData);

    //for mongoose variable
    // router.prototype("/register", (req,res)=>{
        var formData = req.body;
        var salt = bcrypt.genSaltSync(15);
        var user = new User({
            name : formData.name,
            email : formData.email,
            password : bcrypt.hashSync(formData.password,salt)
        });
        //console.log(bcypt.compareSync(formData.password, user.password))
    user.save(function(err){
    if(err){
        res.send("errror in saving data");
    }
    res.send("Saved Successfully");
    });
});

module.exports = router;