var mongoose = require("mongoose");

var UserSchema = mongoose.Schema({
    //  firstName : String,
    name: { type: String, minlength: 3, required: true },
    email: { type: String, required: true },
    password: { type: String, required: true, minlength: 8 }
});

module.exports = mongoose.model("user", UserSchema);