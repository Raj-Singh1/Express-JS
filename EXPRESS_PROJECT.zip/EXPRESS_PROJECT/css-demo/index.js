var http = require("http");
// var { requesthandler } = require("./requesthandler");

// var server = http.createServer(requesthandler);

const app = require("./server");
var server = http.createServer(app);

server.listen(7000, (err) => {
    if (err) {
        console.log("Could not start server");
        return;
    }
    console.log("Server started in port 7000");
});