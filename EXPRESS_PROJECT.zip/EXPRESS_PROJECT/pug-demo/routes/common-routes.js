const express = require("express");
var router = express.Router();

router.get("/", (req, res) => {
    res.header("Content-Type", "text/html").render("index")
});

router.get("/about", (req, res) => {
    res.header("Content-Type", "text/html").send("About")
});

router.get("/contact", (req, res) => {
    res.header("Content-Type", "text/html").send("Contact")
});

module.exports = router;