const express = require("express");

var router = express.Router();

router.get("/list", (req, res) => {
    res.header("Content-Type", "text/html").send("Product List")
});

router.get("/add", (req, res) => {
    res.header("Content-Type", "text/html").send("Product Added")
});

router.get("/remove", (req, res) => {
    res.header("Content-Type", "text/html").send("Product Removed")
});

module.exports = router;