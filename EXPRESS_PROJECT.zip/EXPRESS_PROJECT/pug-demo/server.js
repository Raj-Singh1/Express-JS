const cookieParser = require("cookie-parser");
const session = require("express-session");
const express = require("express");
const bodyParser = require("body-parser");
//create express app object 
var app = express();

//set the view engine
app.set("views", "views");
app.set("view engine", "pug");

app.use("/", (req,res,next)=>{     //"/" for all function
    req.author = "Ratna Sagar";
    req.verified = true;
    next(); 
})

// app.use("/about", (req,res,next)=>{     //"/about" for only about function
//     req.author = "Ratna Sagar";
//     req.verified = true;
//     next(); 
// })

app.use(cookieParser("mysecretkey"));
app.use(session({
                name: "session",
                resave: true,
                saveUninitialized: false,
                secret: "mysecretsessionkey"
            }));

//config request handlers
app.get("/", test, (req,res) => {    //test is using for custom middleware
    res.cookie("company", "Capgemini", {maxAge : 60000, signed:true});       //{expires : new Date(2018,12,31)}
    res.cookie("place", "Bangalore");
    console.log(req.sessionID);
    req.session.Department="Consulting";
    req.session.Salary=15596;
    res.header("Content-Type", "text/html").send("<h2>HOME PAGE</h2>" + req.message);
});

app.get("/about", (req,res) => {
    console.log(req.cookies);
//    var companyName = req.cookies.company || "NIL";
    var companyName = req.signedCookies.company || "NIL";
    var place = req.cookies.place || "NIL";
    var dept = req.session.Department || "NIL";
    var salary = req.session.Salary || 0;
    //res.clearCookie("company");
    //res.clearCookie("place");
  //  req.session.destroy();
    res.header("Content-Type", "text/html")
    .send(`<h2>ABOUT PAGE</h2> <p>Company ${companyName}<br> Location ${place}</p>
    <p>Session ${dept} ${salary}`)  //here req.message will not come because test middleware is not called in "/about"
});

app.get("/contact", (req,res) => {
    res.header("Content-Type", "text/html").send("<h2>CONTACT PAGE</h2>"+req.author);
});

module.exports = app;

function test(req,res,next){
req.message="Hello";
next();
}